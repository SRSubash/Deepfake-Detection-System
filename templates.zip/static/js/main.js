document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById('uploadForm');
  const videoInput = document.getElementById('videoInput');
  const videoPreview = document.getElementById('videoPreview');
  const videoPreviewContainer = document.getElementById('videoPreviewContainer');
  const processingMessage = document.getElementById('processingMessage');
  const resultBox = document.getElementById('resultBox');
  const resetBtn = document.getElementById('resetBtn');

  // ✅ Force video container to be visible if there's a result
  videoPreviewContainer.style.display = 'block';

  videoInput.addEventListener('change', function () {
    const file = videoInput.files[0];
    if (file) {
      const url = URL.createObjectURL(file);
      videoPreview.src = url;
      videoPreviewContainer.style.display = 'block';
      processingMessage.textContent = '';
      if (resultBox) {
        resultBox.style.display = 'none';
        resultBox.innerHTML = '';
      }
    }
  });

  form.addEventListener('submit', function () {
    processingMessage.innerHTML = `
      <div class="spinner"></div>
      <p>Please wait... Detecting deepfake</p>
    `;
  });

  resetBtn.addEventListener('click', function () {
    form.reset();
    videoPreview.src = '';
    videoPreviewContainer.style.display = 'none';
    processingMessage.textContent = '';
    if (resultBox) {
      resultBox.style.display = 'none';
      resultBox.innerHTML = '';
    }
  });
});
